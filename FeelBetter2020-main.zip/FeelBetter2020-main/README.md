# FeelBetter2020
KSU Senior Project Health Mobile Application

This project demonstrates the integration of the Apple ResearchKit and CareKit frameworks using the SwiftUI programing language to create a custom mobile application. 
This application is for demonstartion purposes only.

The application demonstrates: 
- Successful implemntatinon of many SwiftUI workflows and design structures
- Extensin of the CareKit objects to conform to additional protocols useful for a SwiftUI implementation
- Creation of a medical resource guidebook of common childhood resources
- Implementation of visual menu structures to organize medical information
- Implementation of CareKit care plans in a unique short term plan format

Incomplete Features -
- Care plans for all medical conditions except for the Fever care plan
