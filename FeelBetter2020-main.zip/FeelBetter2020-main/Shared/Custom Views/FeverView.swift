//
//  FeverView.swift
//  FeelBetter (iOS)
//
//  Created by Jason on 10/19/20.
//

import SwiftUI
/*
struct FeverView<Page: View>: View {
    var viewControllers
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct FeverView_Previews: PreviewProvider {
    static var previews: some View {
        FeverView()
    }
}
*/
