//
//  LeftArmSymptomDiagnosis.swift
//  FeelBetter (iOS)
//
//  Created by Jason Bice on 11/2/20.
//

import SwiftUI

struct LeftArmSymptomDiagnosis: View {
    var body: some View {
        Text("Left Arm Page")
    }
}

struct LeftArmSymptomDiagnosis_Previews: PreviewProvider {
    static var previews: some View {
        LeftArmSymptomDiagnosis()
    }
}
