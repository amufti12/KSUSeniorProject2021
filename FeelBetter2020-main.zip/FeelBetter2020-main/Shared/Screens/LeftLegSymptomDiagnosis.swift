//
//  LeftLegSymptomDiagnosis.swift
//  FeelBetter (iOS)
//
//  Created by Jason Bice on 11/2/20.
//

import SwiftUI

struct LeftLegSymptomDiagnosis: View {
    var body: some View {
        Text("Left Leg Page")
    }
}

struct LeftLegSymptomDiagnosis_Previews: PreviewProvider {
    static var previews: some View {
        LeftLegSymptomDiagnosis()
    }
}
