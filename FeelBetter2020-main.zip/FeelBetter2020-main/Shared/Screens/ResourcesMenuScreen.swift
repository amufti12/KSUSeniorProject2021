//
//  ResourcesMenuScreen.swift
//  FeelBetter (iOS)
//
//  Created by Jason Bice on 11/2/20.
//

import SwiftUI

struct ResourcesMenuScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ResourcesMenuScreen_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesMenuScreen()
    }
}
