//
//  RightArmSymptomDiagnosis.swift
//  FeelBetter (iOS)
//
//  Created by Jason Bice on 11/2/20.
//

import SwiftUI

struct RightArmSymptomDiagnosis: View {
    var body: some View {
        Text("Right Arm Page")
    }
}

struct RightArmSymptomDiagnosis_Previews: PreviewProvider {
    static var previews: some View {
        RightArmSymptomDiagnosis()
    }
}
