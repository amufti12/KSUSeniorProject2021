//
//  TorsoSymptomDiagnosis.swift
//  FeelBetter (iOS)
//
//  Created by Jason Bice on 11/2/20.
//

import SwiftUI

struct TorsoSymptomDiagnosis: View {
    var body: some View {
        Text("Torso Page")
    }
}

struct TorsoSymptomDiagnosis_Previews: PreviewProvider {
    static var previews: some View {
        TorsoSymptomDiagnosis()
    }
}
